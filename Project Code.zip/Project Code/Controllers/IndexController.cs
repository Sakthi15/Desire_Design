﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using DDMVC.Models;

namespace DDMVC.Controllers
{
    public class IndexController : Controller
    {
        // GET: Index
        DD_MVCEntities obj = new DD_MVCEntities();
        public ActionResult Home()
            
        {
            return View();
        }
        public ActionResult Living()
        {
            return View();
        }
        public ActionResult Kitchen()
        {
            return View();
        }
        public ActionResult Lights()
        {
            return View();
        }
        public ActionResult Bathroom()
        {
            return View();
        }
        public ActionResult Bedroom()
        {
            return View();
        }
        public ActionResult Wardrobe()
        {
            return View();
        }
        public ActionResult Glassware()
        {
            return View();
        }
        public ActionResult Table_showpiece()
        {
            return View();
        }
        public ActionResult Wall_accests()
        {
            return View();
        }
        public ActionResult Career()
        {
            return View();
        }
        [HttpPost]
        public JsonResult InsertCareer(PROFESSIONAL_REGSISTRATION oc)
        {
            Nullable<int> result = 0;
            string Namee = oc.Namee;
            string Mobile = oc.Mobile;
            string Emailid = oc.Emailid;
            string Addresss = oc.Address;
            string Intern = oc.Internship_name;
            if (ModelState.IsValid)
            {
                result = obj.professional_insert(Namee, Mobile, Emailid, Addresss, Intern);
            }
            int result1 = result.Value;

            return Json(result1, JsonRequestBehavior.AllowGet);
        }
            public ActionResult About_us()
        {
            return View();
        }
        public ActionResult Online()
        {
            return View();
        }


        [HttpPost]
        public JsonResult InsertOnline(ONLINE_CONSULTATION oc)
        {
            Nullable<int> result = 0;
            string Namee = oc.Namee;
            string Adhar = oc.Aadhar_number;
            string Mobile = oc.Mobile;
            string Emailid = oc.Emailid;
            string Addresss = oc.Addresss;
            string Property_Name = oc.Property_Name;
            if (ModelState.IsValid)
            {
                result = obj.online_insert(Namee, Adhar, Mobile, Emailid, Addresss, Property_Name);
            }

            int result1 = result.Value;

            return Json(result1, JsonRequestBehavior.AllowGet);

        }
        public ActionResult Payment()
        {
            return View();
        }
        [HttpPost]
        public JsonResult InsertPayment(PAYMENT oc)
        {
            Nullable<int> result = 0;
            string Aadhar_number = oc.Aadhar_number;
            string Item_code = oc.Item_code;
            string Amount = oc.Amount;
            string Card_Holder = oc.Card_Holder;
            string Card_Number = oc.Card_Number;
            string Expiry = oc.Expiry_Datee;
            string CVV = oc.CVV;
            if (ModelState.IsValid)
            {
                result = obj.payment_insert(Aadhar_number, Item_code, Amount, Card_Holder, Card_Number, Expiry, CVV);
            }
            int result1 = result.Value;

            return Json(result1, JsonRequestBehavior.AllowGet);

        }
        public ActionResult Feedback()
        {
            return View();
        }
        [HttpPost]
        public JsonResult InsertFeedback(FEEDBACK oc)
        {
            Nullable<int> result=0;
            string Comment = oc.Comment;
            string Adhar = oc.Aadhar_number;
            string Rating = oc.Rating;
            if (ModelState.IsValid)
            {
                result = obj.feedback_insert(Adhar, Comment, Rating);
            }
            int result1 = result.Value;

            return Json(result1, JsonRequestBehavior.AllowGet);

        }
        public ActionResult Privacy()
        {
            return View();
        }
        public ActionResult Terms()
        {
            return View();
        }
    }
}