﻿
$(function () {
    $("#btnpost").click(function () {
        var online = new Object();
        online.Namee = $('#txtname').val();
        online.Mobile = $('#txtmobile').val();
        online.Emailid = $('#txtemail').val();
        online.Address = $('#txtaddress').val();
        online.Internship_name = $('#txtintern').val();

        if (online != null) {
            $.ajax({
                type: "POST",
                url: "/Index/InsertCareer",
                data: JSON.stringify(online),
                contentType: "application/json; charset=utf-8",
                dataType: "json",
                success: function (response) {
                    console.log(response);
                    if (response > 0) {
                        alert("You have been registered");

                    } else {
                        alert("Fill all the fields correctly");
                    }
                },
                error: function (response) {
                    alert(response.responseText);
                }
            });
        }
    });
});