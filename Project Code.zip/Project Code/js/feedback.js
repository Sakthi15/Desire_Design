﻿
$(function () {
    $("#btnpost").click(function () {
        var online = new Object();
        online.Aadhar_number = $('#textadhar').val();
        online.Comment = $('#txtcomt').val();
        online.Rating = $('#txtrating').val();

        if (online != null) {
            $.ajax({
                type: "POST",
                url: "/Index/InsertFeedback",
                data: JSON.stringify(online),
                contentType: "application/json; charset=utf-8",
                dataType: "json",
                success: function (response) {
                    console.log(response);
                    if (response > 0) {
                        alert("Thank you for your Response");

                    } else {
                        alert("Fill all the fields correctly");
                    }
                },
                error: function (response) {
                    alert(response.responseText);
                }
            });
        }
    });
});