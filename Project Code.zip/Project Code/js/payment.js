﻿
$(function () {
    $("#btnpost").click(function () {
        var online = new Object();

        online.Aadhar_number = $('#txtaadhar').val();
        online.Card_Holder = $('#txtcardname').val();
        online.Card_Number = $('#txtcardnumber').val();
        online.Expiry_Datee = $('#txtcarddate').val();
        online.CVV = $('#txtcvv').val();
        online.Amount = $('#txtamount').val();
        online.Item_code = $('#txtitem').val();
        if (online != null) {
            $.ajax({
                type: "POST",
                url: "/Index/InsertPayment",
                data: JSON.stringify(online),
                contentType: "application/json; charset=utf-8",
                dataType: "json",
                success: function (response) {
                    console.log(response);
                    if (response > 0) {
                        alert("Payment successful");

                    } else {
                        alert("Fill all the fields correctly");
                    }
                },
                error: function (response) {
                    alert(response.responseText);
                }
            });
        }
    });
});