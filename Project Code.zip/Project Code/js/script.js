﻿
$(function () {
    $("#btnpost").click(function () {
        var online = new Object();
        online.Namee = $('#txtname').val();
        online.Aadhar_number = $('#txtaadhar').val();
        online.Mobile = $('#txtmobile').val();
        online.Emailid = $('#txtemail').val();
        online.Addresss = $('#txtaddress').val();
        online.Property_Name = $('#txtpname').val();

        if (online != null) {
            $.ajax({
                type: "POST",
                url: "/Index/InsertOnline",
                data: JSON.stringify(online),
                contentType: "application/json; charset=utf-8",
                dataType: "json",
                success: function (response) {
                    console.log(response);
                    if (response > 0) {
                        alert("Booked your consultation");

                    } else {
                        alert("Fill all the fields correctly");
                    }
                },
                error: function (response) {
                    alert(response.responseText);
                }
            });
        }
    });
});